package com.infosys.exchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
